package com.cg.uas.bean;

public class ProgramsOffered {
	private String programName;
	private String description;
	private String eligibility;
	private int duration;
	private String degreeCertOffered;
	
	public String getProgramName() {
		return programName;
	}
	
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getEligibility() {
		return eligibility;
	}
	
	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}
	
	public int getDuration() {
		return duration;
	}
	
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	public String getDegreeCertOffered() {
		return degreeCertOffered;
	}
	
	public void setDegreeCertOffered(String degreeCertOffered) {
		this.degreeCertOffered = degreeCertOffered;
	}

	
	public ProgramsOffered() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProgramsOffered(String programName, String description,
			String eligibility, int duration, String degreeCertOffered) {
		super();
		this.programName = programName;
		this.description = description;
		this.eligibility = eligibility;
		this.duration = duration;
		this.degreeCertOffered = degreeCertOffered;
	}

	@Override
	public String toString() {
		return "Administrator Bean [ Program Name = " + programName
				+ ", Description = " + description + ", Eligibility = "
				+ eligibility + ", Duration = " + duration
				+ ", Degree Certificate Offered = " + degreeCertOffered + " ]";
	}
	
}
