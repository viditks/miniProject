package com.cg.uas.exception;

public class UniversityException extends Exception {

	public UniversityException(String msg) {
		super(msg);
	}
}
