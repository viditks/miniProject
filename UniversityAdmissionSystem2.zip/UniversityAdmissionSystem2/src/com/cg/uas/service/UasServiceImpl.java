package com.cg.uas.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.uas.bean.AdministratorBean;
import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.UsersBean;
import com.cg.uas.dao.UasDao;
import com.cg.uas.dao.UasDaoImpl;
import com.cg.uas.exception.UniversityException;

public class UasServiceImpl implements UasService{

	UasDao uasDao = null;
	UsersBean users = null;
	
	public UasServiceImpl() {
		uasDao = new UasDaoImpl();
	}
	
	@Override
	public ArrayList<String> getProgramsScheduled() throws UniversityException {
		
		return uasDao.getProgramsScheduled();
	}
	
	@Override
	public int setNewApplicant(ApplicantBean app) throws UniversityException {
		
		return uasDao.setNewApplicant(app);
	}
	
	@Override
	public int addProgramsOffered(AdministratorBean admin)
			throws UniversityException {
		// TODO Auto-generated method stub
		return uasDao.addProgramsOffered(admin);
	}
	
	@Override
	public int updateProgramsOffered(AdministratorBean admin)
			throws UniversityException {
		// TODO Auto-generated method stub
		return uasDao.updateProgramsOffered(admin);
	}
	
	@Override
	public int deleteProgramsOffered(AdministratorBean admin)
			throws UniversityException {
		// TODO Auto-generated method stub
		return uasDao.deleteProgramsOffered(admin);
	}
	
	@Override
	public boolean matchCredentials(String lgnid, String pswd, String roles) throws UniversityException {
		// TODO Auto-generated method stub
		
		users = uasDao.loginAdmin(roles);
		
		if (Pattern.matches(rolePattern, role))
		{
			return true;
		}
		
		else {
			throw new UniversityException("")
		}
		
		return false;
	}
	@Override
	public ArrayList<UsersBean> loginAdmin(String user) throws UniversityException {
		// TODO Auto-generated method stub
		return uasDao.loginAdmin(adminid);
	}

}
