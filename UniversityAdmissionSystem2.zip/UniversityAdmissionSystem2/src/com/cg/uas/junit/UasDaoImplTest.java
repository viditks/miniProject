package com.cg.uas.junit;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.bean.ProgramsScheduled;
import com.cg.uas.bean.Users;
import com.cg.uas.dao.UasDao;
import com.cg.uas.dao.UasDaoImpl;
import com.cg.uas.exception.UniversityException;

public class UasDaoImplTest {
	
	static UasDao uasDao = null;
	
	static ApplicantBean ab = null;
	static ProgramsOffered programsOffered = null;
	static ProgramsOffered programsOfferedNew = null;
	static ProgramsScheduled programsScheduled = null;
	static Users users = null;
	
	@BeforeClass
	public static void beforeClass() throws UniversityException
	{
		uasDao = new UasDaoImpl();
		
		ab = new ApplicantBean(uasDao.generateAppId(), "AAA", LocalDate.now(),
				"BBB", 50.50f, "CCC", "a@gmail.com", "not assigned yet",
				"A123", "received", LocalDate.now()); 
		
		programsOffered = new ProgramsOffered("AAA", "BBB", "CCC", 4, "YES");
		
		programsOfferedNew = new ProgramsOffered("DDD", "EEE", "FFF", 4, "NO");
		
		programsScheduled = new ProgramsScheduled(String.valueOf(uasDao.generateScheduledProgId()), "AAA",
				"BBB", LocalDate.now(), LocalDate.now(), 10);
		
		users = new Users("AAA", "BBB");
	}
	
	@Test
	public void testGetProgramsScheduled() throws UniversityException
	{
		Assert.assertNotNull(uasDao.getProgramsScheduled());
	}
	
	@Test
	public void testSetNewApplicantBean() throws UniversityException
	{
		Assert.assertEquals(1, uasDao.setNewApplicant(ab));
	}
	
	@Test(expected=Exception.class)
	public void testSetNewApplicantBean1() throws UniversityException
	{
		Assert.assertEquals(1, uasDao.setNewApplicant(ab));
	}
	
	@Test
	public void testGetUserCredentials() throws UniversityException
	{
		Assert.assertNotNull(uasDao.getUserCredentials("mac"));
	}
	
	@Test
	public void testGetApplicants() throws UniversityException
	{
		Assert.assertNotNull(uasDao.getApplicants("AAA", "BBB"));
	}
	
	@Test
	public void testUpdateApplicationDetails() throws UniversityException
	{
		Assert.assertNotNull(uasDao.updateApplicationDetails(250, "Accepted", LocalDate.now()));
	}
	
	@Test
	public void testAddProgramScheduled() throws UniversityException
	{
		Assert.assertEquals(1, uasDao.addProgramScheduled(programsScheduled));
	}
	
	@Test(expected=Exception.class)
	public void testAddProgramScheduled1() throws UniversityException
	{
		Assert.assertEquals(1, uasDao.addProgramScheduled(programsScheduled));
	}
	
	@Test
	public void testDeleteProgramScheduled() throws UniversityException
	{
		Assert.assertNotNull(uasDao.deleteProgramScheduled(1001));
	}
	
	@Test
	public void testAddProgramsOffered() throws UniversityException
	{
		Assert.assertEquals(1, uasDao.addProgramsOffered(programsOffered));
	}
	
	@Test(expected=Exception.class)
	public void testAddProgramsOffered1() throws UniversityException
	{
		Assert.assertEquals(1, uasDao.addProgramsOffered(programsOffered));
	}
	
	@Test
	public void testUpdateProgramsOffered() throws UniversityException
	{
		Assert.assertNotNull(uasDao.updateProgramsOffered(programsOfferedNew));
	}
	
	public void testDeleteProgramsOffered() throws UniversityException
	{
		Assert.assertNotNull(uasDao.deleteProgramsOffered("2005"));
	}

}
