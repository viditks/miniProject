package com.cg.uas.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.uas.bean.AdministratorBean;
import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.UsersBean;
import com.cg.uas.exception.UniversityException;
import com.cg.uas.util.DBUtil;

public class UasDaoImpl implements UasDao {

	Connection conn = null;
	PreparedStatement pst = null;
	Statement st = null;
	ResultSet rs = null;

	//returns programs_scheduled record
	@Override
	public ArrayList<String> getProgramsScheduled() throws UniversityException {

		String selProgSch = "SELECT * FROM programs_scheduled";
		ArrayList<String> progSchList = new ArrayList<String>();

		try {

			conn = DBUtil.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(selProgSch);

			while(rs.next()) {

				progSchList.add(rs.getString("program_name"));

			}
		} 
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return progSchList;
	}

	//inserting new applicant
	@Override
	public int setNewApplicant(ApplicantBean app) throws UniversityException {
		String insQry = "INSERT INTO application values(?,?,?,?,?,?,?,?,?,?)";
		int dataAdded = 0;
		try {
			conn = DBUtil.getConnection();
			st = conn.createStatement();
			pst = conn.prepareStatement(insQry);
			
			pst.setInt(1,generateAppId());
			pst.setString(2, app.getFullName());
			pst.setDate(3, app.getDateOfBirth());
			pst.setString(4, app.getQualification());
			pst.setFloat(5, app.getMarks());
			pst.setString(6, app.getGoals());
			pst.setString(7, app.getEmail());
			pst.setInt(8, app.getScheduledProgId());
			pst.setString(9, app.getStatus());
			pst.setDate(10, app.getInterviewDate());
			
			dataAdded = pst.executeUpdate();
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return dataAdded;
	}

	private int generateAppId() throws UniversityException {
		String qry = "SELECT appliaction_id_seq.NEXTVAL FROM DUAL";
		int generateValue;
		
		try {
			conn = DBUtil.getConnection();
			st = conn.createStatement();
			rs = st.executeQuery(qry);
			
			rs.next();
			generateValue = rs.getInt(1);
		} 
		catch (Exception e) {
			throw new UniversityException(e.getMessage());
		}
		finally{

			try{
				conn.close();
				st.close();
				rs.close();
			}
			catch(Exception e){
				throw new UniversityException(e.getMessage());
			}
		}

		return generateValue;
	}

	@Override
	public int addProgramsOffered(AdministratorBean admin)
			throws UniversityException {
		// TODO Auto-generated method stub
		
		String insertQry = "insert into Programs_Offered"
				+ "(program_name, description, applicant_eligibility, duration, "
				+ "degree_certificate_offered) values(?, ?, ?, ?, ?)";
		
		int dataAdded = 0;
		
		try
		{
			conn = DBUtil.getConnection();
			
			pst = conn.prepareStatement(insertQry);
			
			pst.setString(1, admin.getProgramName());
			
			pst.setString(2, admin.getDescription());
			
			pst.setString(3, admin.getEligibility());
			
			pst.setString(4, admin.getDuration());
			
			pst.setString(5, admin.getDegreeCertOffered());
			
			dataAdded = pst.executeUpdate();
			
			System.out.println("Program Inserted into the Table"
					+ " Programs Offered");
		}
		
		catch (Exception e)
		{
			throw new UniversityException(e.getMessage());
		}
		
		finally
		{
			try
			{
				conn.close();
				
				pst.close();
			}
			
			catch (SQLException se)
			{
				throw new UniversityException(se.getMessage());
			}
		}
		
		return dataAdded;
	}

	@Override
	public int updateProgramsOffered(AdministratorBean admin)
			throws UniversityException {
		// TODO Auto-generated method stub
		
		String qry = "update Programs_Offered set description = '?', "
				+ "applicant_eligibilty = '?', duration = ?, "
				+ "degree_certificate_offered = '?'"
				+ " where program_name = '?'";
		
		int dataUpdated = 0;
		
		try
		{
			conn = DBUtil.getConnection();
			
			pst = conn.prepareStatement(qry);
			
			pst.setString(1, admin.getDescription());
			
			pst.setString(2, admin.getEligibility());
			
			pst.setString(3, admin.getDuration());
			
			pst.setString(4, admin.getDegreeCertOffered());
			
			dataUpdated = pst.executeUpdate();
			
			System.out.println("Programs offered Table is updated");
		}
		
		catch (Exception e)
		{
			throw new UniversityException(e.getMessage());
		}
		
		finally
		{
			try {
				conn.close();
				
				pst.close();
			} 
			
			catch (SQLException se) {
				// TODO: handle exception
				
				throw new UniversityException(se.getMessage());
			}
		}
		
		return dataUpdated;
	}

	@Override
	public int deleteProgramsOffered(AdministratorBean admin)
			throws UniversityException {
		// TODO Auto-generated method stub
		
		String qry = "delete from Programs_Offered where program_name"
				+ " = ?";
		
		int dataDeleted = 0;
		
		try
		{
			conn = DBUtil.getConnection();
			
			pst = conn.prepareStatement(qry);
			
			pst.setString(1, admin.getProgramName());
			
			dataDeleted = pst.executeUpdate();
			
			System.out.println("Data Deleted from the Programs Offered Table");
		}
		
		catch (Exception e)
		{
			throw new UniversityException(e.getMessage());
		}
		
		finally
		{
			try
			{
				conn.close();
				
				pst.close();
			}
			
			catch (SQLException se)
			{
				throw new UniversityException(se.getMessage());
			}
		}
		
		return dataDeleted;
	}

	@Override
	public ArrayList<UsersBean> loginAdmin(String user) throws UniversityException {
		// TODO Auto-generated method stub
		
		ArrayList<UsersBean> adminList = new ArrayList<UsersBean>();
		
		String qry = "select * from users where role = 'admin'";
		
		UsersBean login = null;
		
		try
		{
			conn = DBUtil.getConnection();
			
			st = conn.createStatement();
			
			rs = st.executeQuery(qry);
			
			while (rs.next())
			{
				login = new UsersBean(rs.getString("login_id"), 
						rs.getString("password"), rs.getString("role"));
				
				adminList.add(login);
			}
			
			
		}
		
		catch (Exception e)
		{
			throw new UniversityException(e.getMessage());
		}
		
		finally
		{
			try
			{
				conn.close();
				
				pst.close();
			}
			
			catch (SQLException se)
			{
				throw new UniversityException(se.getMessage());
			}
		}
		
		return adminList;
	}

}
